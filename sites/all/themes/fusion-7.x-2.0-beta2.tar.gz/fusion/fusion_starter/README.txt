--- WHAT IS fusion_starter? ---

fusion_starter is a subtheme of the Fusion core theme (http://www.drupal.org/project/fusion). If you want to create a subtheme of Fusion, you can start here! This theme is designed to have full markup for ease of theming. If you want a minimal markup theme, please see fusion_starter_lite.

--- CREATING A SUBTHEME ---

First and foremost, copy this directory (/sites/all/themes/fusion_starter) to your themes directory and rename it to a new theme name. This prevents your subtheme from being overwritten when Fusion Core is updated.

Please see the README.txt of the Fusion Core directory for basic information on creating a subtheme, or go directly to http://fusiondrupalthemes.com/support/theme-developers/subtheming-quickstart for help jumpstarting your theme.
